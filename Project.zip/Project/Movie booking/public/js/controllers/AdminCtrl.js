sampleApp.controller('AdminController', function($scope, $http,$log)
{

    $scope.tagline = 'ADMIN PANEL';
});
